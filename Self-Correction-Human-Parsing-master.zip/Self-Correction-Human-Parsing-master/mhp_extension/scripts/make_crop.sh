python make_crop_and_mask_w_mask_nms.py \
	--img_dir './data/CIHP/Testing/Images' \
	--save_dir './data/CIHP/' \
	--img_list './data/CIHP/annotations/CIHP_val.json' \
	--det_res './data/CIHP/detectron2_prediction/inference/instances_predictions.pth'

